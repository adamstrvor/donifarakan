

supported_languages = [{'code':'fr','name':'🇫🇷 Français'},{'code':'en','name':'🇬🇧 English'},{'code':'bm','name':'🇲🇱 Bamanan'}]