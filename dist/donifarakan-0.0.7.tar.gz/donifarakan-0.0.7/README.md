# Introduction

Dɔni farakan also known as "Dɔni fara ɲɔgɔn kan" (in Bambara) is a powerful package designed in the frame of Federated Learning to facilitate distributed machine learning while preserving data privacy. This framework enables multiple clients to collaboratively train machine learning models without sharing their raw data.

The documentation will be provided shortly!

# Intallation instructions


# Getting started


# Requirements

# Contribution


# FAQ

# License